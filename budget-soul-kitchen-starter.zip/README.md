# Budget Soul Kitchen

Set-it-and-forget-it Black Southern meals under $20. Built for GitHub Pages.

**Deploy:** Settings → Pages → Branch: `main`, Folder: `/ (root)`.

© 2025 Jeffrey Levels
